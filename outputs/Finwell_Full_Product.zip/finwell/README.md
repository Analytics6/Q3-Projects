# Finwell — Cards & Loans Support Assistant

Finwell is a full-stack retrieval assistant for common Indian credit-card, debit-card, home-loan, and personal-loan issues. It includes a Flask API, Next.js customer dashboard, administrator console, secure login, conversation history, and a 50-PDF knowledge base.

## Stack

- **Frontend:** Next.js App Router, TypeScript, responsive dashboard UI.
- **Backend:** Flask, Python `sqlite3`, password hashing, HttpOnly JWT cookies, CSRF checks, roles, rate limits, and structured errors.
- **RAG:** LangChain PDF loading/chunking, OpenAI embeddings and chat, Pinecone in production, Chroma locally, hybrid lexical/dense reranking, and page-level citations.
- **Evaluation and operations:** RAGAS faithfulness/relevancy endpoint, LangSmith tracing endpoint, MLflow REST logging endpoint, document processing history, and admin metrics.
- **Persistence:** Local SQLite in development and hosted SQLite-compatible Turso/libSQL for Vercel. Vercel function disk is ephemeral, so production needs Turso and Pinecone.

## Local setup

1. Copy `.env.example` to `.env`; set `JWT_SECRET_KEY` and `OPENAI_API_KEY`.
2. Install Python and Node dependencies: `python -m pip install -r requirements-local.txt` and `npm install`.
3. Start the Flask API with `python -m backend.app`.
4. Start Next.js in another terminal with `npm run dev`.
5. Open `http://localhost:3000`. The Next.js dev server forwards `/api/*` to Flask at port 5000.
6. Create the first admin with `python scripts/create_admin.py`.
7. Generate or refresh the PDFs with `python scripts/build_knowledge_base.py`, then index all 50 using `python scripts/ingest_knowledge.py`.

## Admin console

Use the command-line admin setup; public sign-up only creates normal user accounts. Admins can view operational metrics, upload up to five PDFs per job, reindex the bundled 50 documents, inspect pages/chunks/errors and ingestion history, run RAGAS evaluations, view LangSmith traces, and log metrics to MLflow.

## API endpoints

All routes use `/api`.

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | Readiness |
| POST | `/auth/register` | Customer registration |
| POST / GET | `/auth/login`, `/auth/me` | Sign in and current profile |
| POST | `/auth/logout` | Clear session cookies |
| GET / POST | `/conversations` | List or create conversations |
| GET / DELETE | `/conversations/<id>` | Read or delete a conversation |
| GET / POST | `/conversations/<id>/messages` | Read history or ask a sourced question |
| POST | `/chat/completions` | One-turn RAG response |
| GET | `/models` | Chat model and prompt strategies |
| GET | `/admin/overview` | Admin operations metrics |
| GET | `/admin/documents`, `/admin/ingestion-runs` | Knowledge inventory and job details |
| GET | `/admin/evaluations` | Saved RAGAS runs |
| POST | `/admin/knowledge/ingest`, `/admin/knowledge/reindex` | Process PDFs or reindex bundled corpus |
| POST | `/admin/evaluations/ragas` | Evaluate up to four sample questions |
| GET | `/admin/langsmith/traces` | LangSmith trace listing |
| GET / POST | `/admin/mlflow/status`, `/admin/mlflow/runs` | Check tracking and log run metrics |

The prompt selector offers standard, stepwise evidence review (CoT-style), and multi-path answer selection (ToT-style). Hidden reasoning and draft candidates are not returned to customers. Every answer is grounded in retrieved pages, includes citations, and uses a fallback when evidence is insufficient.

## Vercel deployment

1. Push the repository to Git and import its root as a single Vercel project.
2. Create a Turso database and a Pinecone index with **1536 dimensions** and **cosine** metric.
3. Configure the following Vercel environment variables:
   - `FLASK_ENV=production`
   - `JWT_SECRET_KEY` (random secret, at least 32 characters)
   - `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`
   - `PINECONE_API_KEY`, `PINECONE_INDEX`
   - `OPENAI_API_KEY`
   - `FRONTEND_ORIGIN` (your Vercel deployment origin)
   - `REDIS_URL` (shared serverless rate limiting)
   - Optional: `LANGSMITH_API_KEY`, `LANGSMITH_PROJECT`, `LANGSMITH_TRACING_ENABLED`, `MLFLOW_TRACKING_URI`, `MLFLOW_TRACKING_USERNAME`, `MLFLOW_TRACKING_PASSWORD`
4. Deploy the site. With the same production environment variables set locally, run `python scripts/create_admin.py`, then `python scripts/ingest_knowledge.py` to create the admin and index the included PDF corpus into durable services.

`vercel.json` sends `/api/*` to the Flask Python Function. The Vercel project and external service accounts must be connected by the owner; no credentials are included. Production startup requires Redis so login and chat limits are shared across serverless instances.

## Included reference material

`knowledge_base/pdfs/` contains 50 individually generated reference PDFs: 13 credit-card, 12 debit-card, 13 home-loan, and 12 personal-loan documents. The documents are general support guidance, include official RBI source links where relevant, and explain safe escalation without promising customer outcomes. The source manifest is `knowledge_base/manifest.json`.

Do not enter full card numbers, CVV, PIN, OTP, password, or full identity numbers. This application is an educational support assistant, not a lender or financial/legal adviser; confirm all account-specific terms with the institution.

LangSmith tracing is off by default. Enabling it can send prompt text, retrieved passages, and model responses to the configured LangSmith project; review the bank's data-handling requirements and LangSmith retention settings before turning it on for real customer traffic.

